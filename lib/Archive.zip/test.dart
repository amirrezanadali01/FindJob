import 'package:flutter/material.dart';

class TestListViewAnimation extends StatefulWidget {
  const TestListViewAnimation({Key? key}) : super(key: key);

  @override
  State<TestListViewAnimation> createState() => _TestListViewAnimationState();
}

class _TestListViewAnimationState extends State<TestListViewAnimation> {
  List listItems = ['hellow', 'world', 'bannana', 'bannana', 'bannana'];
  final GlobalKey<AnimatedListState> _listMyKey =
      GlobalKey<AnimatedListState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: AnimatedList(
          key: _listMyKey,
          initialItemCount: listItems.length,
          itemBuilder: (context, index, anim) {
            return templateCard(
                index: index.toString(),
                anim: anim,
                onClick: () {
                  listItems.removeAt(index);
                  _listMyKey.currentState!.removeItem(
                      index,
                      (context, animation) => templateCard(
                          index: index.toString(),
                          anim: animation,
                          onClick: () {}));
                });
          }),
    );
  }
}

class templateCard extends StatelessWidget {
  const templateCard(
      {Key? key,
      required this.index,
      required this.anim,
      required this.onClick})
      : super(key: key);

  final String index;
  final VoidCallback onClick;
  final Animation<double> anim;

  @override
  Widget build(BuildContext context) {
    return SlideTransition(
      position: Tween<Offset>(
        begin: const Offset(-1, 0),
        end: const Offset(0, 0),
      ).animate(anim),
      child: SizedBox(
          height: 100,
          child: Card(
            color: Colors.white,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(index),
                GestureDetector(onTap: onClick, child: Text('delet'))
              ],
            ),
          )),
    );
  }
}
