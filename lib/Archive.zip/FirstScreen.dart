import 'package:findjob/SecondScreen.dart';
import 'package:sizer/sizer.dart';
import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

class FirstScreen extends StatefulWidget {
  const FirstScreen({Key? key}) : super(key: key);

  @override
  State<FirstScreen> createState() => _FirstScreenState();
}

class _FirstScreenState extends State<FirstScreen>
    with TickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<Offset> animTop;
  late Animation<Offset> animRight;
  late Animation<Offset> animLeft;
  late Animation<Offset> animText;
  late Animation<double> animOpacity;
  @override
  void initState() {
    _controller = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 800));

    animOpacity = Tween<double>(begin: 1, end: 0).animate(_controller);

    animTop = Tween<Offset>(begin: const Offset(0, 0), end: const Offset(0, -1))
        .animate(_controller);

    animRight =
        Tween<Offset>(begin: const Offset(0, 0), end: const Offset(1, 0))
            .animate(_controller);

    animLeft =
        Tween<Offset>(begin: const Offset(0, 0), end: const Offset(-1, 0))
            .animate(_controller);

    animText =
        Tween<Offset>(begin: const Offset(0, 0), end: const Offset(0, -0.50))
            .animate(_controller);

    _controller.addListener(() {
      if (_controller.isCompleted) {
        Navigator.push(
            context, MaterialPageRoute(builder: (context) => SecondScreen()));
      }
    });

    super.initState();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: const Color(0xFF0F1214),
        body: Column(
          children: [
            Expanded(
              flex: 7,
              child: Stack(
                children: [
                  Positioned(
                    right: -15,
                    bottom: 3.h,
                    child: SlideTransition(
                        position: animRight,
                        child: SizedBox(
                          width: 60.w,
                          height: 40.h,
                          child: Card(
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(30)),
                              child: const Image(
                                  fit: BoxFit.cover,
                                  image: AssetImage('assets/images/a3.jpg'))),
                        )),
                  ),
                  Positioned(
                    right: 20,
                    top: -10.h,
                    child: SlideTransition(
                        position: animTop,
                        child: SizedBox(
                          width: 50.w,
                          height: 40.h,
                          child: Card(
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(30)),
                              clipBehavior: Clip.antiAlias,
                              child: const Image(
                                  fit: BoxFit.cover,
                                  image: AssetImage('assets/images/a1.jpg'))),
                        )),
                  ),
                  Positioned(
                    top: 13.h,
                    left: -20,
                    child: SlideTransition(
                        position: animLeft,
                        child: SizedBox(
                          width: 60.w,
                          height: 40.h,
                          child: Card(
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(30)),
                              clipBehavior: Clip.antiAlias,
                              child: const Image(
                                  fit: BoxFit.cover,
                                  image: AssetImage('assets/images/a2.jpg'))),
                        )),
                  ),
                ],
              ),
            ),
            Expanded(
                child: SlideTransition(
              position: animText,
              child: FadeTransition(
                opacity: animOpacity,
                child: Text(
                  'the new era \n of recruitment',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Colors.white, fontSize: 29.50.sp),
                ),
              ),
            )),
            const SizedBox(height: 15),
            Expanded(
              child: SlideTransition(
                position: animText,
                child: FadeTransition(
                  opacity: animOpacity,
                  child: const Text(
                    'find your best job or create vacancies and look for\nnew colleagues right here.',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: Colors.white38),
                  ),
                ),
              ),
            ),
            Expanded(
              child: GestureDetector(
                onTap: () => _controller.forward(),
                child: FadeTransition(
                  opacity: animOpacity,
                  child: Container(
                      margin:
                          const EdgeInsets.only(bottom: 10, left: 5, right: 5),
                      decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius:
                              BorderRadius.all(Radius.circular(100.w))),
                      child: const Center(
                          child: Text(
                        'get start',
                        style: TextStyle(fontSize: 20),
                      ))),
                ),
              ),
            )
          ],
        ));
  }
}
