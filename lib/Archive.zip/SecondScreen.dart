import 'dart:ffi';

import 'package:findjob/FourScreen.dart';
import 'package:findjob/ThirScreen.dart';
import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

class SecondScreen extends StatefulWidget {
  const SecondScreen({Key? key}) : super(key: key);

  @override
  State<SecondScreen> createState() => _SecondScreenState();
}

class _SecondScreenState extends State<SecondScreen>
    with TickerProviderStateMixin {
  late AnimationController _controller;
  late AnimationController _controller2;

  late Animation<Offset> animSkip;
  late Animation<Offset> animArrow;
  late Animation<Offset> animText;

  late Animation<Offset> animJob;
  late Animation<Offset> animEmployee;

  late Animation<double> animOpacity;
  late Animation<double> animOpacity2;

  bool isContinue = false;
  final GlobalKey<AnimatedListState> _listKey = GlobalKey<AnimatedListState>();

  // tow part

  late Animation<Offset> animProfile;
  late Animation<Offset> animTask;
  late Animation<Offset> animList;
  List<String> items = [
    "interview with the candidate to ios developer position",
    "meeting new employees in the office",
    "1 on 1 with the head of the design department",
    "interview with the candidate to ios developer position",
    "1 on 1 with the head of the design department"
  ];

  @override
  void initState() {
    _controller = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 800));

    _controller2 = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 800));

    animOpacity = Tween<double>(begin: 0, end: 1).animate(_controller);

    animSkip =
        Tween<Offset>(begin: const Offset(0.80, 0), end: const Offset(0, 0))
            .animate(_controller);

    animArrow =
        Tween<Offset>(begin: const Offset(-0.80, 0), end: const Offset(0, 0))
            .animate(_controller);

    animText =
        Tween<Offset>(begin: const Offset(0, -0.30), end: const Offset(0, 0))
            .animate(_controller);

    animJob =
        Tween<Offset>(begin: const Offset(-0.1, 0), end: const Offset(0, 0))
            .animate(_controller);

    animEmployee =
        Tween<Offset>(begin: const Offset(0.1, 0), end: const Offset(0, 0))
            .animate(_controller);

    // tow animation

    animOpacity2 = Tween<double>(begin: 0, end: 1).animate(_controller2);

    animProfile =
        Tween<Offset>(begin: const Offset(0, 0.10), end: const Offset(0, 0))
            .animate(_controller2);

    animTask =
        Tween<Offset>(begin: const Offset(0, 0.30), end: const Offset(0, 0))
            .animate(_controller2);

    animList =
        Tween<Offset>(begin: const Offset(-0.10, 0), end: const Offset(0, 0))
            .animate(_controller2);

    Future.delayed(const Duration(milliseconds: 400), () {
      _controller.forward();
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // F6F6F6
      backgroundColor: Color(0xFFF6F6F6),
      body: Stack(
        children: [
          Positioned(
            top: 10.h,
            child: SlideTransition(
              position: animProfile,
              child: FadeTransition(
                opacity: animOpacity2,
                child: Padding(
                  padding: const EdgeInsets.only(left: 20, right: 20),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(children: [
                        ClipRRect(
                          borderRadius: BorderRadius.circular(15),
                          child: Image(
                            image: const AssetImage('assets/images/b2.jpg'),
                            fit: BoxFit.cover,
                            width: 50.sp,
                            height: 50.sp,
                          ),
                        ),
                        SizedBox(
                          width: 2.w,
                        ),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            SizedBox(height: 5.sp),
                            const Text(
                              'morning',
                              style: TextStyle(
                                  color: Colors.grey,
                                  fontSize: 20,
                                  fontWeight: FontWeight.w700),
                            ),
                            SizedBox(height: 1.h),
                            const Text(
                              'Mira',
                              style: TextStyle(
                                  fontSize: 20, fontWeight: FontWeight.w700),
                            ),
                          ],
                        ),
                      ]),
                      SizedBox(
                        width: 40.w,
                      ),
                      Icon(Icons.notifications_active_outlined, size: 20.sp)
                    ],
                  ),
                ),
              ),
            ),
          ),
          Positioned(
              left: 7.w,
              top: 40.h,
              child: FadeTransition(
                opacity: animOpacity2,
                child: SlideTransition(
                  position: animTask,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'tasks',
                        style: TextStyle(
                            fontWeight: FontWeight.bold, fontSize: 17.sp),
                      ),
                      SizedBox(width: 65.w),
                      Icon(Icons.add, size: 20.sp),
                    ],
                  ),
                ),
              )),
          Positioned(
            top: 45.h,
            left: 2.w,
            right: 2.w,
            child: FadeTransition(
              opacity: animOpacity2,
              child: SlideTransition(
                position: animList,
                child: SizedBox(
                  height: 90.h,
                  width: 100.w,
                  child: AnimatedList(
                      key: _listKey,
                      initialItemCount: items.length,
                      itemBuilder: (context, indext, animate) {
                        return templateItems(
                          anim: animate,
                          text: items[indext],
                          onClick: () {
                            _listKey.currentState!.removeItem(
                                indext,
                                duration: const Duration(milliseconds: 900),
                                (context, animation) => templateItems(
                                    text: items[indext],
                                    anim: animation,
                                    onClick: () {}));
                            items.removeAt(indext);
                          },
                        );
                      }),
                ),
              ),
            ),
          ),
          AnimatedPositioned(
            duration: const Duration(milliseconds: 800),
            top: isContinue == false ? 0.h : 20.h, // 20.h
            left: isContinue == false ? 0 : 3,
            right: isContinue == false ? 0 : 3,
            child: AnimatedContainer(
              decoration: BoxDecoration(
                  color: const Color(0xFF0F1214),
                  borderRadius:
                      BorderRadius.all(Radius.circular(isContinue ? 10.w : 0))),
              duration: const Duration(milliseconds: 800),

              width: 100.w,
              height: isContinue == false ? 100.h : 15.h, // 20.h
              child: Column(
                children: [
                  Expanded(
                      flex: 2,
                      child: Padding(
                        padding: EdgeInsets.symmetric(horizontal: 10.sp),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            SlideTransition(
                              position: animArrow,
                              child: FadeTransition(
                                opacity: animOpacity,
                                child: const Icon(
                                  Icons.arrow_back,
                                  color: Colors.white,
                                ),
                              ),
                            ),
                            SlideTransition(
                              position: animSkip,
                              child: FadeTransition(
                                opacity: animOpacity,
                                child: Text(
                                  'skip',
                                  style: TextStyle(
                                      color: Colors.white38, fontSize: 13.sp),
                                ),
                              ),
                            ),
                          ],
                        ),
                      )),
                  Expanded(
                    flex: 1,
                    child: SlideTransition(
                      position: animText,
                      child: FadeTransition(
                        opacity: animOpacity,
                        child: Column(
                          children: [
                            Text(
                              'choose the job type',
                              style: TextStyle(
                                  color: Colors.white, fontSize: 30.sp),
                            ),
                            SizedBox(height: 12.sp),
                            Text(
                              'are you looking for a new job or new employee?',
                              style: TextStyle(
                                  color: Colors.white38, fontSize: 11.sp),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  SizedBox(height: 15.sp),
                  Expanded(
                      flex: 2,
                      child: Row(
                        children: [
                          Expanded(
                            child: SlideTransition(
                              position: animJob,
                              child: FadeTransition(
                                opacity: animOpacity,
                                child: Container(
                                  margin: const EdgeInsets.all(2),
                                  decoration: BoxDecoration(
                                      color: const Color(0xFF1F2124),
                                      borderRadius: BorderRadius.all(
                                          Radius.circular(8.w))),
                                  child: Column(
                                    children: [
                                      SizedBox(height: 4.h),
                                      Icon(
                                        Icons.work_outline,
                                        size: 25.sp,
                                        color: Colors.white54,
                                      ),
                                      SizedBox(height: 2.h),
                                      Text(
                                        'find job',
                                        style: TextStyle(
                                            color: Colors.white,
                                            fontSize: 15.sp),
                                      ),
                                      SizedBox(height: 1.h),
                                      Text(
                                        'we have a lot of job\nopenings',
                                        style: TextStyle(
                                            color: Colors.white38,
                                            fontSize: 11.sp),
                                        textAlign: TextAlign.center,
                                      )
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Expanded(
                              child: SlideTransition(
                            position: animEmployee,
                            child: FadeTransition(
                              opacity: animOpacity,
                              child: Container(
                                margin: const EdgeInsets.all(2),
                                decoration: BoxDecoration(
                                    color: const Color(0xFF1F2124),
                                    borderRadius:
                                        BorderRadius.all(Radius.circular(8.w))),
                                child: Column(
                                  children: [
                                    SizedBox(height: 4.h),
                                    Icon(
                                      Icons.man,
                                      size: 25.sp,
                                      color: Colors.white54,
                                    ),
                                    SizedBox(height: 2.h),
                                    Text(
                                      'find an employee',
                                      style: TextStyle(
                                          color: Colors.white, fontSize: 15.sp),
                                    ),
                                    SizedBox(height: 1.h),
                                    Text(
                                      'thousands of people are\nready to work with vou',
                                      style: TextStyle(
                                          color: Colors.white38,
                                          fontSize: 11.sp),
                                      textAlign: TextAlign.center,
                                    )
                                  ],
                                ),
                              ),
                            ),
                          )),
                        ],
                      )),
                  SizedBox(height: isContinue == false ? 25.h : 0),
                  Expanded(
                      flex: 0,
                      child: GestureDetector(
                        onTap: () {
                          _controller.reverse();

                          Future.delayed(const Duration(seconds: 1), () {
                            setState(() {
                              isContinue = true;
                            });
                            Future.delayed(const Duration(milliseconds: 200),
                                () {
                              _controller2.forward();
                            });
                          });
                        },
                        child: FadeTransition(
                          opacity: animOpacity,
                          child: Container(
                              height: 10.h,
                              margin: const EdgeInsets.only(
                                  bottom: 10, left: 5, right: 5),
                              decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius:
                                      BorderRadius.all(Radius.circular(100.w))),
                              width: double.infinity,
                              child: const Center(
                                  child: Text(
                                'continue',
                                style: TextStyle(fontSize: 20),
                              ))),
                        ),
                      )),
                ],
              ),
            ),
          ),
          Positioned(
              top: 24.h,
              left: 10.w,
              child: FadeTransition(
                opacity: animOpacity2,
                child: GestureDetector(
                  onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => const ThirScreen())),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'you have 17 new applications',
                        style: TextStyle(color: Colors.white, fontSize: 15.sp),
                      ),
                      const SizedBox(height: 10),
                      Text(
                        'check them right now',
                        style:
                            TextStyle(color: Colors.white38, fontSize: 12.sp),
                      ),
                    ],
                  ),
                ),
              )),
        ],
      ),
    );
  }
}

class templateItems extends StatelessWidget {
  const templateItems(
      {super.key,
      required this.text,
      required this.anim,
      required this.onClick});

  final String text;
  final VoidCallback onClick;
  final Animation<double> anim;

  @override
  Widget build(BuildContext context) {
    return SlideTransition(
      // sizeFactor: anim,
      position: Tween<Offset>(
        begin: const Offset(1, 0),
        end: const Offset(0, 0),
      ).animate(anim),
      child: Container(
        margin: const EdgeInsets.only(bottom: 2),
        width: 100.w,
        padding: EdgeInsets.all(20.sp),
        decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.all(Radius.circular(20.sp))),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: const [
                      Icon(Icons.access_time, color: Colors.grey),
                      SizedBox(width: 10),
                      Text(
                        'today/2 pm - 4 pm',
                        style: TextStyle(color: Colors.grey),
                      )
                    ],
                  ),
                  SizedBox(height: 10.sp),
                  Text(
                    text,
                    style: const TextStyle(fontWeight: FontWeight.w500),
                  )
                ],
              ),
            ),
            IconButton(onPressed: onClick, icon: const Icon(Icons.done))
          ],
        ),
      ),
    );
  }
}
