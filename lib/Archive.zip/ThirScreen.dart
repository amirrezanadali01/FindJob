import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

class ThirScreen extends StatefulWidget {
  const ThirScreen({Key? key}) : super(key: key);

  @override
  State<ThirScreen> createState() => _ThirScreenState();
}

class _ThirScreenState extends State<ThirScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Color(0xFFF6F6F6), // F6F6F6
        body: CustomScrollView(
          slivers: [
            const SliverAppBar(
              snap: false,
              pinned: true,
              floating: false,
              stretch: true,
              centerTitle: true,
              expandedHeight: 200,
              backgroundColor: Colors.black,
              flexibleSpace: FlexibleSpaceBar(
                  title: Text('Hanna Dias'),
                  centerTitle: true,
                  stretchModes: [
                    StretchMode.zoomBackground,
                    StretchMode.blurBackground,
                    StretchMode.fadeTitle
                  ],
                  background: Image(
                    image: AssetImage('assets/images/b1.jpg'),
                    fit: BoxFit.cover,
                  )),
            ),
            SliverList(
                delegate: SliverChildListDelegate([
              Padding(
                padding: EdgeInsets.only(left: 15.sp, right: 10.sp),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(height: 5.h),
                    const Text(
                      'about me',
                      style:
                          TextStyle(fontWeight: FontWeight.bold, fontSize: 20),
                    ),
                    SizedBox(height: 2.h),
                    const Text(
                      'i have been working as a i/ux designer for more than 3 years. i am engaged in the... more',
                      style: TextStyle(
                          color: Colors.grey, fontWeight: FontWeight.w500),
                    ),
                    SizedBox(height: 4.h),
                    const Text(
                      'skills',
                      style:
                          TextStyle(fontWeight: FontWeight.bold, fontSize: 20),
                    ),
                  ],
                ),
              ),
              SizedBox(
                height: 2.h,
              ),
              Row(
                children: [
                  Expanded(
                      child: Container(
                    margin: EdgeInsets.only(left: 1.sp, right: 1.sp),
                    height: 16.h,
                    decoration: const BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.all(Radius.circular(20))),
                    child: Column(
                      children: [
                        const SizedBox(height: 15),
                        Expanded(
                          flex: 2,
                          child: Image.asset('assets/images/figma.png'),
                        ),
                        const SizedBox(height: 10),
                        const Expanded(
                            child: Text(
                          'figma',
                          style: TextStyle(fontWeight: FontWeight.w600),
                        )),
                        const Expanded(
                            child: Text(
                          '10 / 10',
                          style: TextStyle(color: Colors.grey),
                        )),
                        const SizedBox(height: 15),
                      ],
                    ),
                  )),
                  Expanded(
                      child: Container(
                    margin: EdgeInsets.only(left: 1.sp, right: 1.sp),
                    height: 16.h,
                    decoration: const BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.all(Radius.circular(20))),
                    child: Column(
                      children: [
                        const SizedBox(height: 15),
                        Expanded(
                          flex: 2,
                          child: Image.asset('assets/images/after.png'),
                        ),
                        const SizedBox(height: 10),
                        const Expanded(
                            child: Text(
                          'after effects',
                          style: TextStyle(fontWeight: FontWeight.w600),
                        )),
                        const Expanded(
                            child: Text(
                          '8 / 10',
                          style: TextStyle(color: Colors.grey),
                        )),
                        const SizedBox(height: 15),
                      ],
                    ),
                  )),
                  Expanded(
                      child: Container(
                    margin: EdgeInsets.only(left: 1.sp, right: 1.sp),
                    height: 16.h,
                    decoration: const BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.all(Radius.circular(20))),
                    child: Column(
                      children: [
                        const SizedBox(height: 15),
                        Expanded(
                          flex: 2,
                          child: Image.asset('assets/images/ilstrator.png'),
                        ),
                        const SizedBox(height: 10),
                        const Expanded(
                            child: Text(
                          'illustrator',
                          style: TextStyle(fontWeight: FontWeight.w600),
                        )),
                        const Expanded(
                            child: Text(
                          '7 / 10',
                          style: TextStyle(color: Colors.grey),
                        )),
                        const SizedBox(height: 15),
                      ],
                    ),
                  )),
                ],
              ),
              SizedBox(height: 2.h),
              Padding(
                padding: EdgeInsets.only(left: 15.sp, bottom: 15.sp),
                child: const Text(
                  'experience',
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20),
                ),
              ),
              Container(
                margin: EdgeInsets.only(left: 3.sp, right: 3.sp, bottom: 3.sp),
                decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(20)),
                width: double.infinity,
                height: 13.h,
                child: Padding(
                  padding: EdgeInsets.only(left: 10.sp, right: 10.sp),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.all(7),
                            width: 16.w,
                            height: 7.h,
                            decoration: const BoxDecoration(
                                borderRadius:
                                    BorderRadius.all(Radius.circular(15)),
                                color: Color(0xFFF6F6F6) // F6F6F6
                                ),
                            child: Image.asset('assets/images/google.png'),
                          ),
                          SizedBox(width: 10.sp),
                          Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text(
                                'lead ux/ui',
                                style: TextStyle(fontWeight: FontWeight.bold),
                              ),
                              SizedBox(height: 4.sp),
                              const Text(
                                'google inc',
                                style: TextStyle(
                                    color: Colors.grey,
                                    fontWeight: FontWeight.w600),
                              )
                            ],
                          )
                        ],
                      ),
                      Text(
                        '02/2021 -now',
                        style: TextStyle(fontWeight: FontWeight.bold),
                      )
                    ],
                  ),
                ),
              ),
              Container(
                margin: EdgeInsets.only(left: 3.sp, right: 3.sp, bottom: 3.sp),
                decoration: BoxDecoration(
                    color: Color(0xFFF9F9F9), // F9F9F9
                    borderRadius: BorderRadius.circular(20)),
                width: double.infinity,
                height: 13.h,
                child: Padding(
                  padding: EdgeInsets.only(left: 10.sp, right: 10.sp),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.all(7),
                            width: 16.w,
                            height: 7.h,
                            decoration: const BoxDecoration(
                                borderRadius:
                                    BorderRadius.all(Radius.circular(15)),
                                color: Color(0xFFF6F6F6) // F6F6F6
                                ),
                            child: Image.asset('assets/images/snapchat.png'),
                          ),
                          SizedBox(width: 10.sp),
                          Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text(
                                'senior ux/ui',
                                style: TextStyle(fontWeight: FontWeight.bold),
                              ),
                              SizedBox(height: 4.sp),
                              const Text(
                                'snap inc',
                                style: TextStyle(
                                    color: Colors.grey,
                                    fontWeight: FontWeight.w600),
                              )
                            ],
                          )
                        ],
                      ),
                      const Text(
                        '07/2020 - 01/2021',
                        style: TextStyle(
                            fontWeight: FontWeight.bold, color: Colors.grey),
                      )
                    ],
                  ),
                ),
              ),
              Container(
                margin: EdgeInsets.only(left: 3.sp, right: 3.sp, bottom: 3.sp),
                decoration: BoxDecoration(
                    color: Color(0xFFF9F9F9), // F9F9F9
                    borderRadius: BorderRadius.circular(20)),
                width: double.infinity,
                height: 13.h,
                child: Padding(
                  padding: EdgeInsets.only(left: 10.sp, right: 10.sp),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.all(7),
                            width: 16.w,
                            height: 7.h,
                            decoration: const BoxDecoration(
                                borderRadius:
                                    BorderRadius.all(Radius.circular(15)),
                                color: Color(0xFFF6F6F6) // F6F6F6
                                ),
                            child: Image.asset('assets/images/twitter.png'),
                          ),
                          SizedBox(width: 10.sp),
                          Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text(
                                'middle ux/ui',
                                style: TextStyle(fontWeight: FontWeight.bold),
                              ),
                              SizedBox(height: 4.sp),
                              const Text(
                                'twitter',
                                style: TextStyle(
                                    color: Colors.grey,
                                    fontWeight: FontWeight.w600),
                              )
                            ],
                          )
                        ],
                      ),
                      const Text(
                        '08/2018 - 05/2020',
                        style: TextStyle(
                            fontWeight: FontWeight.bold, color: Colors.grey),
                      )
                    ],
                  ),
                ),
              ),
              Container(
                margin: EdgeInsets.only(left: 3.sp, right: 3.sp, bottom: 3.sp),
                decoration: BoxDecoration(
                    color: Color(0xFFF9F9F9), // F9F9F9
                    borderRadius: BorderRadius.circular(20)),
                width: double.infinity,
                height: 13.h,
                child: Padding(
                  padding: EdgeInsets.only(left: 10.sp, right: 10.sp),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.all(7),
                            width: 16.w,
                            height: 7.h,
                            decoration: const BoxDecoration(
                                borderRadius:
                                    BorderRadius.all(Radius.circular(15)),
                                color: Color(0xFFF6F6F6) // F6F6F6
                                ),
                            child: Image.asset('assets/images/pocket.png'),
                          ),
                          SizedBox(width: 10.sp),
                          Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text(
                                'junior ux/ui',
                                style: TextStyle(fontWeight: FontWeight.bold),
                              ),
                              SizedBox(height: 4.sp),
                              const Text(
                                'pocket inc',
                                style: TextStyle(
                                    color: Colors.grey,
                                    fontWeight: FontWeight.w600),
                              )
                            ],
                          )
                        ],
                      ),
                      const Text(
                        '03/2017 - 07/2018',
                        style: TextStyle(
                            fontWeight: FontWeight.bold, color: Colors.grey),
                      )
                    ],
                  ),
                ),
              ),
            ])),
          ],
        ));
  }
}
